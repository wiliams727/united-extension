NOTES

App Name: 
Quick Skips

FEATURES

Auto-select Search Type
Auto Skip building
Skip Editor
Quick Search


DISPOSITIONS
(*): Confirmed number for person. Confirm through voicemail, conversation with person.
LVM: Left voicemail
NVM: No voicemail
VMF: Voicemail full
BN: Bad number / Do not call
TI: Person took information
HU: Hung up
DISC: Number is disconnected


REFERENCES TEMPLATE

NAME | RELATIONSHIP
SSN | DOB (AGE)
ADDRESS
PHONE.NUMBER  ...  
PHONE.NUMBER  ...  

ROBERT WILLIAM STALLINGS | Brother
229-59-0858 | 09/07/1990 (35)
3720 COLLEGE PARK DR APT 1208, CONROE, TX 77384
(903) 812-8885  ...  
(903) 808-6096  ...   
(757) 431-2411  ...   
(682) 334-9611  ...  
(940) 435-0333  ...  

KNOWN ISSUES

When you open too many tabs at the same time, the app doesn't work properly. It might not load and redirect to home page