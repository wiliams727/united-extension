// Is Search Type Page
// *******************
// Returns true when the current page is the Delvepoint search type screen.
function isSearchTypePage() {
  return location.href.includes("/Luna/DSUIServicesApplicationUI/searchTypes/reSearch");
}

// Set Select By Option Text
// *******************
// Selects an option by visible text and fires input events.
function setSelectByOptionText(selectEl, wantedText) {
  const options = Array.from(selectEl.options);
  const match = options.find(o => (o.textContent || "").trim() === wantedText);
  if (!match) return false;

  selectEl.value = match.value;

  // Trigger the site's dynamic UI updates
  selectEl.dispatchEvent(new Event("input", { bubbles: true }));
  selectEl.dispatchEvent(new Event("change", { bubbles: true }));
  return true;
}

// Set Select By Value
// *******************
// Selects an option by value and fires input events.
function setSelectByValue(selectEl, wantedValue) {
  const options = Array.from(selectEl.options);
  const match = options.find(o => o.value === wantedValue);
  if (!match) return false;

  selectEl.value = wantedValue;
  selectEl.dispatchEvent(new Event("input", { bubbles: true }));
  selectEl.dispatchEvent(new Event("change", { bubbles: true }));
  return true;
}

// Configure Search Type Page
// *******************
// Auto-fills the search type flow and advances to the next page.
function configureSearchTypePage() {

  // Step 1: Search Group = People
  const group = document.querySelector("#searchTypeGroup");
  if (!group) return;

  // If already set, don't spam events
  if (group.value !== "People") {
    const okGroup = setSelectByValue(group, "People");
    if (!okGroup) return;
  }

  // Step 2: Search Type = Advanced Person Search Plus (appears dynamically)
  const type = document.querySelector("#searchTypeHash");
  if (!type) return;

  // Only select if not already chosen
  const wantedTypeText = "Advanced Person Search Plus";
  const currentText = (type.options[type.selectedIndex]?.textContent || "").trim();
  if (currentText !== wantedTypeText) {
    const okType = setSelectByOptionText(type, wantedTypeText);
    if (!okType) return;
  }

  // Step 3: Click Next (appears dynamically)
  const nextBtn = document.querySelector("#nextBtn");
  if (!nextBtn) return;

  // Click only once per page load
  if (document.documentElement.dataset.dpAutoNextClicked === "1") return;
  document.documentElement.dataset.dpAutoNextClicked = "1";

  nextBtn.click();
}

// Configure Search Page
// *******************
// Dismisses the duplicate search dialog when it appears.
function configureSearchPage() {
  const nextBtn = document.querySelector("#duplicateSearchDialog > .formButton");
  if (!nextBtn) return;
  nextBtn.click();
}

// Current Page
// *******************
// Returns the current Delvepoint page type used by the automation flow.
function currentPage() {
  // Search Type page
  if (location.href.includes("/Luna/DSUIServicesApplicationUI/searchTypes/reSearch")) {
    return 1;
  }
  // Search page
  else if (location.href.includes("app.delvepoint.com/Luna/search/")) {
    return 2;
  }
  else if (location.href.includes("app.delvepoint.com/Luna/searchTypes/")) {
    return 2;
  }

}

// Auto Configure Page
// *******************
// Runs the correct page automation based on the current page.
function autoConfigurePage() {
  switch (currentPage()) {
    case 1:
      configureSearchTypePage();
      break;

    case 2:
      configureSearchPage();

    default:
      break;
  }
}

// Remove Elements From View
// *******************
// Hides parts of the Delvepoint page that are not needed for this workflow.
function removeElementsFromView() {

  let element = document.getElementById("researchContainer");
  element.style.display = "none";
  
  element = document.getElementById("searchOptionsSidebar").parentElement;
  element.style.display = "none";
}

// Format Phones
// *******************
// Joins extracted phone numbers into the skip template format.
function formatPhones(phones) {
  let formatted = [];
  for (const numbers of phones) {
    formatted.push(numbers.number);
  }
  return formatted.join("  ...  \n");
}


// Build Skip Template
// *******************
// Builds the skip text using the selected person's information.
function buildSkipTemplate({ person }) {
  if (!person) {
    return "";
  }

  return (
`NAME
${person.name}

ADDRESS
${person.addresses[0].addy}

CLAIM


SSN
${person.ssn}

DOB
${person.dob}

AGE
${person.age}

WORK


REFERENCES/RELATIVES


PRIME/CELL
${formatPhones(person.phones)}  ...  `
);
}

// Find Reusable Empty Skip
// *******************
// Returns the active empty skip that can be replaced with person data.
function findReusableEmptySkip(skipsMap, activeSkipId) {
  if (!activeSkipId) return null;

  const activeSkip = skipsMap?.[activeSkipId];
  if (!activeSkip || activeSkip.type !== "skip") return null;

  const isEmptyTitle = (activeSkip.title || "").trim() === "Empty Note";
  const isEmptyText = !(activeSkip.text || "").trim();

  if (!isEmptyTitle && !isEmptyText) return null;
  return activeSkip;
}

// Has Live Extension Context
// *******************
// Returns false when this content script belongs to an extension instance that was reloaded.
function hasLiveExtensionContext() {
  return Boolean(globalThis.chrome?.runtime?.id);
}

// Copy As Reference
// *******************
// Builds the reference text for copying to the clipboard.
function copyAsReference({ person }) {
  return (
`${person.name} | 
${person.ssn} | ${person.dob} (${person.age})
${person.addresses[0].addy}
${formatPhones(person.phones)}  ...  `
  );
}

// Get Summary Card Items
// *******************
// Extracts values and date ranges from a summary card section.
function getSummaryCardItems(personEl, cardSelector) {
  const rows = Array.from(personEl.querySelectorAll(`${cardSelector} .full`));

  return rows.map(row => {
    const valueEl = row.querySelector(".criteriaPointData");
    const value = normalizeText(valueEl?.textContent || "");
    if (!value) return null;

    const fullText = normalizeText(row.textContent || "");
    const withoutValue = normalizeText(fullText.replace(value, ""));

    const datesMatch = withoutValue.match(/\(?([A-Za-z]{3,9}\s+\d{2,4}\s*-\s*[A-Za-z]{3,9}\s+\d{2,4})\)?/);
    const dates = datesMatch ? datesMatch[1] : "";

    return { value, dates, text: withoutValue };
  }).filter(Boolean);
}

// Get Duration Between Dates
// *******************
// Converts a date range string into a year and month duration.
function getDateDuration(range) {
  const match = range.match(/([A-Za-z]{3})\s+(\d{2,4})\s*-\s*([A-Za-z]{3})\s+(\d{2,4})/);
  if (!match) return "";

  const months = {
    Jan:0, Feb:1, Mar:2, Apr:3, May:4, Jun:5,
    Jul:6, Aug:7, Sep:8, Oct:9, Nov:10, Dec:11
  };

  let startMonth = months[match[1]];
  let startYear = Number(match[2]);
  let endMonth = months[match[3]];
  let endYear = Number(match[4]);

  if (startYear < 100) startYear += startYear >= 50 ? 1900 : 2000;
  if (endYear < 100) endYear += endYear >= 50 ? 1900 : 2000;

  const totalMonths =
    (endYear - startYear) * 12 +
    (endMonth - startMonth);

  const years = Math.floor(totalMonths / 12);
  const monthsLeft = totalMonths % 12;

  return `${years}y ${monthsLeft}m`;
}

// Get Addresses
// *******************
// Returns parsed address objects for a person card.
function getAddresses(personEl) {
  return getSummaryCardItems(personEl, ".summary-card.address").map(item =>
    new Address({
      addy: item.value,
      dates: item.dates,
      time: getDateDuration(item.dates),
      county: ""
    })
  );
}

// Get Phones
// *******************
// Returns parsed phone objects for a person card.
function getPhones(personEl) {
  return getSummaryCardItems(personEl, ".summary-card.phones")
    .slice(0, 6)
    .map(item =>
      new Phone({
        number: item.value,
        dates: item.dates,
        time: getDateDuration(item.dates),
        type: item.text
      })
    );
}

// Create New Person
// *******************
// Builds a person object from a Delvepoint result card.
async function createPerson(personEl, _relationship) {

  // Name, SSN, DOB
  const header = personEl.querySelector(".index-card.searchMain > .card-header");
  if (!header) return { name: "", ssn: "", dob: "", age: "" , addr: "", phones};
  const values = Array.from(header.querySelectorAll(".criteriaPointData"))
    .map(el => normalizeText(el.textContent))
    .filter(Boolean);

  const name = values[0] || "";
  const ssn = values[1] || "";
  const dob = values[2] || "";

  // Age appears in header text like "(51)" after DOB
  const headerText = header.textContent || "";
  const ageMatch = headerText.match(/\((\d{1,3})\)/);
  const age = ageMatch ? ageMatch[1] : "";

  // Addresses and Phones
  const addresses = getAddresses(personEl);
  const phones = getPhones(personEl);
  
  // Create the person
  const person = new Person({
    name,
    dob,
    age,
    ssn,
    relationship: _relationship,
    phones,
    addresses
  });
  return person;
}

// Inject Buttons Into Person
// ***************************
// Adds skip workflow buttons to a person's result card.
function injectButtonsIntoPerson(personEl) {
  if (personEl.dataset.skipButtonsInjected === "1") return;
  removeElementsFromView();
  const cardHeader = personEl.querySelector(".index-card.searchMain > .card-header");
  if (!cardHeader) return;

  // Get the tools bar
  // Put buttons in the card-tools area (right side)
  // Remove existing delvepoint buttons
  let tools = cardHeader.querySelector(".card-tools");
  if (!tools) {
    tools = document.createElement("span");
    tools.className = "card-tools";
    cardHeader.appendChild(tools);
  }
  tools.replaceChildren();
  
  // Add to Skip button
  const addSkipBtn = document.createElement("button");
  addSkipBtn.type = "button";
  addSkipBtn.textContent = "Create Skip";
  addSkipBtn.className = "btn newSkipBtn";

  addSkipBtn.addEventListener("click", async () => {
    try {
      if (!hasLiveExtensionContext()) {
        addSkipBtn.textContent = "Reload Page";
        return;
      }

      const p = await createPerson(personEl, "PRIME");

      const newText = buildSkipTemplate({person: p});
      const title = makeSkipTitle({
        name: p.name,
        ssn: p.ssn,
        phones: p.phones
      });

      const result = await chrome.storage.local.get([SKIPS_KEY, ACTIVE_KEY]);
      const skipsRaw = result[SKIPS_KEY] || {};
      const reusableSkip = findReusableEmptySkip(skipsRaw, result[ACTIVE_KEY]);
      const skipId = reusableSkip?.id || makeSkipId();

      skipsRaw[skipId] = {
        id: skipId,
        type: "skip",
        classification: "NEW",
        title,
        text: newText,
        data: {},
        isOpen: true,
        createdAt: reusableSkip?.createdAt || Date.now()
      };

      await chrome.storage.local.set({
        [SKIPS_KEY]: skipsRaw,
        [ACTIVE_KEY]: skipId
      });

      // Open editor window
      chrome.runtime.sendMessage({ type: "OPEN_EDITOR" });

      addSkipBtn.textContent = "Skip Created!";
      setTimeout(() => (addSkipBtn.textContent = "Create Skip"), 900);
    } catch (error) {
      const message = String(error?.message || error || "");
      if (message.includes("Extension context invalidated") || !hasLiveExtensionContext()) {
        addSkipBtn.textContent = "Reload Page";
        return;
      }

      throw error;
    }
  });

  // 
  const copyAsRefBtn = document.createElement("button");
  copyAsRefBtn.type = "button";
  copyAsRefBtn.textContent = "Copy Reference";
  copyAsRefBtn.className = "btn exportSkipBtn";

  copyAsRefBtn.addEventListener("click", async (e) => {
    const p = await createPerson(personEl, "PRIME");

    const copyRef = copyAsReference({person: p});

    await navigator.clipboard.writeText(copyRef);

    copyAsRefBtn.textContent = "Reference Copied!";
    setTimeout(() => (copyAsRefBtn.textContent = "Copy Reference"), 900);
  });

  tools.appendChild(addSkipBtn);
  tools.appendChild(copyAsRefBtn);

  personEl.dataset.skipButtonsInjected = "1";
}

// Click View Recent Search
// *******************
// Runs when the page loads and waits until the button exists
// Then clicks the button automatically
window.addEventListener("load", () => {
  const interval = setInterval(() => {
    const btn = document.querySelector('input[name="_eventId_viewRecentSearch"]');

    if (btn) {
      btn.click();
      clearInterval(interval);
    }
  }, 200);
  //sessionRenewalOfferMessageResponse
});

// Scan and Inject
// *******************
// Scans visible person cards and injects the skip buttons.
function scanAndInject() {
  const people = document.querySelectorAll('div[id^="person_"]');
  people.forEach(injectButtonsIntoPerson);
}

// ***************
// content.js/main
// ***************

// Initial pass
autoConfigurePage();
scanAndInject();

// If results load dynamically, keep watching
const observer = new MutationObserver(() => {
  autoConfigurePage();
  scanAndInject();
});

observer.observe(document.documentElement, { childList: true, subtree: true });
