const STORAGE_KEY = "qs_text";
const SKIPS_KEY = "qs_skips";
const ACTIVE_KEY = "qs_activeSkipId";

// *******************
// helpers.js/classes
// *******************
class Person {
    // Person Constructor
    // *******************
    // Creates a person record with related summary data.
    constructor({ 
        name = "-", 
        dob = "-", 
        age = "-", 
        relationship = "-", 
        ssn = "-", 
        personID = 0, 
        addresses = [], 
        phones = [] }) {
        
    this.name = name;
    this.dob = dob;
    this.age = age;
    this.relationship = relationship;
    this.ssn = ssn;
    this.personID = personID;
    this.addresses = addresses;
    this.phones = phones;
  }
}

class Phone {
    // Phone Constructor
    // *******************
    // Creates a phone record with number and metadata.
    constructor({ number, dates, time, type }) {
        this.number = number;
        this.dates = dates;
        this.time = time;
        this.type = type;
    }
}

class Address {
    // Address Constructor
    // *******************
    // Creates an address record with date and county metadata.
    constructor({ addy, dates, time, county }) {
        this.addy = addy;
        this.dates = dates;
        this.time = time;
        this.county = county;
    }
}

/* class  {
    // 
    // 
    // 
    // 
} */

// Normalize Text
// *******************
// Collapses whitespace and trims a string value.
function normalizeText(s) {
  return (s ?? "").replace(/\s+/g, " ").trim();
}

// Make Skip Id
// *******************
// Creates a unique id for each saved skip.
function makeSkipId() {
  if (crypto?.randomUUID) return crypto.randomUUID();
  return `skip_${Date.now()}_${Math.random().toString(16).slice(2)}`;
}

// Make Skip Title
// *******************
// Creates a short title from available person details.
function makeSkipTitle({ name = "", ssn = "", phones = "" }) {
  const n = (name || "").trim();
  if (n) return n.length > 22 ? n.slice(0, 22) + "…" : n;
  const s = (ssn || "").trim();
  if (s) return `SSN ${s}`;
  const p = (phones || "").split("\n")[0]?.trim();
  if (p) return `PH ${p}`;
  return "New Skip";
}

// Escape Xml
// *******************
// Escapes XML-sensitive characters in a string.
function escapeXml(str = "") {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

// Download Skip Xml
// *******************
// Builds and downloads a simple XML file for a skip.
function downloadSkipXml(skip) {
  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<skip>
    <text>${escapeXml(skip.text || "")}</text>
</skip>`;

  const blob = new Blob([xml], { type: "application/xml" });
  const url = URL.createObjectURL(blob);

  const a = document.createElement("a");
  a.href = url;
  a.download = `${skip.title || "skip"}.xml`;
  a.click();

  URL.revokeObjectURL(url);
}
