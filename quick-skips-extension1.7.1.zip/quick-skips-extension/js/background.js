const EDITOR_URL = "html/editor.html";
const WINDOW_NAME = "edge-notepad-window";
const HOME_CACHE_TTL_MS = 5 * 60 * 1000;
const HOME_CACHE_KEY = "qs_homeDashboardCache";
const HOME_REFRESH_ALARM = "qs_homeDashboardRefresh";

const PBX_AUTH_HEADER = `Basic ${btoa("maint:xx47j49d7")}`;
const PBX_OUTGOING_URL = "http://pbx20089.8bitllc.com/admin/config.php?type=tool&display=asternic_cdr&tab=outgoing";
const PBX_INCOMING_URL = "http://pbx20089.8bitllc.com/admin/config.php?type=tool&display=asternic_cdr&tab=incoming";
const PBX_COMBINED_URL = "http://pbx20089.8bitllc.com/admin/config.php?type=tool&display=asternic_cdr&tab=combined";

let cachedHomeDashboard = null;

// Open or Focus Editor
// *******************
// Opens the editor popup or focuses the existing one.
async function openOrFocusEditor() {
  const windows = await chrome.windows.getAll({ populate: true });
  const existing = windows.find((windowObj) =>
    windowObj.type === "popup" &&
    windowObj.tabs?.some((tab) => tab.url && tab.url.includes(EDITOR_URL))
  );

  if (existing?.id) {
    await chrome.windows.update(existing.id, { focused: true });
    return;
  }

  await chrome.windows.create({
    url: chrome.runtime.getURL("html/editor.html"),
    type: "popup",
    // Keep the popup at the requested baseline size and make the closing
    // layout adapt to this viewport instead of relying on a larger window.
    width: 600,
    height: 760,
    left: 1010,
    top: 0,
    focused: true
  });
}

function decodeHtmlEntities(text = "") {
  return text
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&quot;/gi, '"')
    .replace(/&#39;/gi, "'")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">");
}

function stripHtml(text = "") {
  return decodeHtmlEntities(String(text || "").replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim());
}

function normalizeHeader(text = "") {
  return String(text || "").replace(/\s+/g, " ").trim().toLowerCase();
}

function getTablesByCaption(html = "", captionText = "") {
  const tables = html.match(/<table[\s\S]*?<\/table>/gi) || [];
  const normalizedCaption = normalizeHeader(captionText);

  if (!normalizedCaption) return tables;

  return tables.filter((tableHtml) => {
    const captionMatch = tableHtml.match(/<caption[^>]*>([\s\S]*?)<\/caption>/i);
    const caption = stripHtml(captionMatch?.[1] || "");
    return normalizeHeader(caption).includes(normalizedCaption);
  });
}

function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function waitForTabComplete(tabId, timeoutMs = 30000) {
  const existing = await chrome.tabs.get(tabId);
  if (existing.status === "complete") {
    await wait(1500);
    return;
  }

  await new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      reject(new Error("Timed out waiting for tab load."));
    }, timeoutMs);

    function listener(updatedTabId, changeInfo) {
      if (updatedTabId !== tabId || changeInfo.status !== "complete") return;
      clearTimeout(timeout);
      chrome.tabs.onUpdated.removeListener(listener);
      resolve();
    }

    chrome.tabs.onUpdated.addListener(listener);
  });

  await wait(1500);
}

async function runInTab(tabId, func, args = []) {
  const results = await chrome.scripting.executeScript({
    target: { tabId },
    func,
    args
  });

  return results?.[0]?.result;
}

function parseSimpleTable(html, requiredHeaders, captionText = "") {
  const tables = getTablesByCaption(html, captionText);

  for (const tableHtml of tables) {
    const headers = Array.from(tableHtml.matchAll(/<th[^>]*>([\s\S]*?)<\/th>/gi)).map((match) => stripHtml(match[1]));
    if (!headers.length) continue;

    const normalizedHeaders = headers.map(normalizeHeader);
    const hasAllHeaders = requiredHeaders.every((header) => normalizedHeaders.includes(normalizeHeader(header)));
    if (!hasAllHeaders) continue;

    const bodyMatch = tableHtml.match(/<tbody[^>]*>([\s\S]*?)<\/tbody>/i);
    const bodyHtml = bodyMatch ? bodyMatch[1] : tableHtml;
    const rowMatches = Array.from(bodyHtml.matchAll(/<tr[^>]*>([\s\S]*?)<\/tr>/gi));
    const records = [];

    for (const rowMatch of rowMatches) {
      const cells = Array.from(rowMatch[1].matchAll(/<td[^>]*>([\s\S]*?)<\/td>/gi)).map((cellMatch) => stripHtml(cellMatch[1]));
      if (!cells.length) continue;

      const record = {};
      headers.forEach((header, index) => {
        record[header] = cells[index] || "";
      });
      records.push(record);
    }

    return records;
  }

  return [];
}

function parsePbxSummaryRecord(html = "", captionText = "") {
  const scopedHtml = getTablesByCaption(html, captionText)[0] || html;
  const labelValuePairs = Array.from(scopedHtml.matchAll(/<td[^>]*>\s*([^<:]+:)\s*<\/td>\s*<td[^>]*>\s*([\s\S]*?)\s*<\/td>/gi))
    .map((match) => ({
      label: stripHtml(match[1]).toLowerCase(),
      value: stripHtml(match[2])
    }));

  const total = labelValuePairs.find((entry) => entry.label === "number of calls:")?.value || "";
  const duration = labelValuePairs.find((entry) => entry.label === "total time:")?.value || "";

  if (!total && !duration) return null;

  return {
    user: "All Users",
    total: total.replace(/\s*calls?$/i, "").trim() || "--",
    duration: duration || "--"
  };
}

async function fetchPbxReport({ url, label, sectionTitle = "" }) {
  try {
    const response = await fetch(url, {
      headers: {
        Authorization: PBX_AUTH_HEADER
      }
    });

    if (!response.ok) {
      throw new Error(`${response.status} ${response.statusText}`);
    }

    const html = await response.text();
    const rows = parseSimpleTable(html, ["User", "Total", "Duration"], sectionTitle);
    const summaryRecord = parsePbxSummaryRecord(html, sectionTitle);
    const records = rows
      .map((row) => ({
        user: row.User || "All Users",
        total: row.Total || "--",
        duration: row.Duration || "--"
      }))
      .filter((row) => row.total !== "--" || row.duration !== "--");

    return {
      ok: true,
      records,
      summaryRecord,
      message: records.length ? "" : `${label}: no user rows were available on the report page.`
    };
  } catch (error) {
    return {
      ok: false,
      records: [],
      summaryRecord: null,
      message: `${label}: ${error.message || "request failed."}`
    };
  }
}

function collectAgents(...groups) {
  const seen = new Set();
  const agents = [];

  for (const group of groups) {
    for (const record of group?.records || []) {
      const candidate = record.user || record.collector || "";
      const cleaned = candidate.replace(/\s+/g, " ").trim();
      if (!cleaned || seen.has(cleaned.toLowerCase())) continue;
      seen.add(cleaned.toLowerCase());
      agents.push(cleaned);
    }
  }

  return agents;
}

function buildHomeDashboardPayload(outgoing, incoming, combined, fetchedAt) {
  const pbxAgents = collectAgents(outgoing, incoming, combined);

  return {
    ok: outgoing.ok || incoming.ok || combined.ok,
    fetchedAt,
    hasData: !!(
      outgoing.records.length ||
      incoming.records.length ||
      combined.records.length ||
      outgoing.summaryRecord ||
      incoming.summaryRecord ||
      combined.summaryRecord
    ),
    pbxAgents,
    requestedAgent: "",
    outgoing,
    incoming,
    combined
  };
}

async function refreshHomeDashboardCache() {
  const [outgoing, incoming, combined] = await Promise.all([
    fetchPbxReport({
      url: PBX_OUTGOING_URL,
      label: "Outgoing calls",
      sectionTitle: "Outgoing Calls"
    }),
    fetchPbxReport({
      url: PBX_INCOMING_URL,
      label: "Incoming calls",
      sectionTitle: "Incoming Calls"
    }),
    fetchPbxReport({
      url: PBX_COMBINED_URL,
      label: "Combined calls",
      sectionTitle: "Incoming / Outgoing"
    })
  ]);

  cachedHomeDashboard = buildHomeDashboardPayload(outgoing, incoming, combined, Date.now());
  await chrome.storage.local.set({ [HOME_CACHE_KEY]: cachedHomeDashboard });
  return cachedHomeDashboard;
}

async function fetchHomeDashboard(forceRefresh = false) {
  if (!forceRefresh) {
    if (cachedHomeDashboard && cachedHomeDashboard.fetchedAt && Date.now() - cachedHomeDashboard.fetchedAt < HOME_CACHE_TTL_MS) {
      return cachedHomeDashboard;
    }

    const stored = await chrome.storage.local.get([HOME_CACHE_KEY]);
    const savedCache = stored[HOME_CACHE_KEY] || null;
    if (savedCache) {
      cachedHomeDashboard = savedCache;
      return savedCache;
    }

    return {
      ok: true,
      fetchedAt: null,
      hasData: false,
      pbxAgents: [],
      outgoing: { ok: true, records: [], message: "" },
      incoming: { ok: true, records: [], message: "" },
      combined: { ok: true, records: [], message: "" }
    };
  }

  return refreshHomeDashboardCache();
}

async function clearHomeDashboard() {
  cachedHomeDashboard = {
    ok: true,
    fetchedAt: null,
    hasData: false,
    pbxAgents: [],
    outgoing: { ok: true, records: [], message: "" },
    incoming: { ok: true, records: [], message: "" },
    combined: { ok: true, records: [], message: "" }
  };

  await chrome.storage.local.remove([HOME_CACHE_KEY]);
  return cachedHomeDashboard;
}

// Runtime Message Handling
// *******************
// Supports popup lifecycle actions and home dashboard fetches.
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type === "OPEN_EDITOR") {
    openOrFocusEditor();
    return;
  }

  if (msg?.type === "FETCH_HOME_DASHBOARD") {
    const fetchPromise = fetchHomeDashboard(!!msg.forceRefresh);

    fetchPromise
      .then((result) => sendResponse(result))
      .catch((error) => {
        sendResponse({
          ok: false,
          fetchedAt: Date.now(),
          pbxAgents: [],
          hasData: false,
          outgoing: { ok: false, records: [], message: error.message || "Dashboard fetch failed." },
          incoming: { ok: false, records: [], message: "" },
          combined: { ok: false, records: [], message: "" }
        });
      });

    return true;
  }

  if (msg?.type === "CLEAR_HOME_DASHBOARD") {
    clearHomeDashboard()
      .then((result) => sendResponse(result))
      .catch((error) => {
        sendResponse({
          ok: false,
          fetchedAt: null,
          hasData: false,
          pbxAgents: [],
          outgoing: { ok: false, records: [], message: error.message || "Unable to clear dashboard cache." },
          incoming: { ok: true, records: [], message: "" },
          combined: { ok: true, records: [], message: "" }
        });
      });

    return true;
  }
});

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create(HOME_REFRESH_ALARM, { periodInMinutes: 5 });
  refreshHomeDashboardCache().catch(() => {});
});

chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create(HOME_REFRESH_ALARM, { periodInMinutes: 5 });
  refreshHomeDashboardCache().catch(() => {});
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm?.name !== HOME_REFRESH_ALARM) return;
  refreshHomeDashboardCache().catch(() => {});
});

// Open editor when clicking the extension icon
chrome.action.onClicked.addListener(async () => {
  openOrFocusEditor();
});
