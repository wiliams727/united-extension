const searchEl = document.getElementById("dpSearchInput");
const homeBtn = document.getElementById("homeBtn");
const skipsBtn = document.getElementById("skipsBtn");
const closingTabBtn = document.getElementById("closingTabBtn");
const mainContentEl = document.getElementById("mainContent");

let saveTimer = null;
let skips = {};
let activeSkipId = null;
let currentEditorEl = null;
let currentView = "home";
let homeDashboardData = null;
let homeSelectedPbxAgent = "";
let homeRefreshInFlight = false;
let allSkipsFilter = "";
let lastViewedSkipId = null;
let closingKeyboardHandler = null;

const SKIP_SECTION_NAMES = [
  "NAME",
  "ADDRESS",
  "CLAIM",
  "SSN",
  "DOB",
  "AGE",
  "WORK",
  "REFERENCES/RELATIVES",
  "PRIME/CELL"
];

const DEFAULT_SKIP_CLASSIFICATION = "🗃️ NEW";
const HOME_PBX_AGENT_KEY = "qs_homePbxAgent";
const LAST_SKIP_KEY = "qs_lastViewedSkipId";
const CURRENT_VIEW_KEY = "qs_currentView";
const HOME_ALL_USERS_LABEL = "All Users";

function normalizeSkipClassification(classification) {
  const cleaned = String(classification || "").trim();

  if (!cleaned) return DEFAULT_SKIP_CLASSIFICATION;
  if (cleaned === "🗃️ NEW" || cleaned === "📞 CALLED IN" || cleaned === "🔥 IMPORTANT") return cleaned;
  if (cleaned === "NEW") return "🗃️ NEW";
  if (cleaned === "CALL IN" || cleaned === "CALLED IN") return "📞 CALLED IN";
  if (cleaned === "NSF" || cleaned === "BROKEN" || cleaned === "IMPORTANT") return "🔥 IMPORTANT";

  return DEFAULT_SKIP_CLASSIFICATION;
}

function normalizeAgentName(value) {
  return String(value || "").replace(/\s+/g, " ").trim().toLowerCase();
}

// Get Active Tab
// *******************
// Returns the currently selected saved item.
function getActiveTab() {
  if (!activeSkipId) return null;
  return skips[activeSkipId] || null;
}

// Navigation state is stored separately from skip content so the popup can
// return to the same working skip even after switching top tabs or reloading.
function normalizeStoredView(view) {
  if (view === "skip" || view === "all-skips" || view === "closing" || view === "home") {
    return view;
  }

  return "home";
}

function rememberSkip(skipId = activeSkipId) {
  const candidate = skipId && skips[skipId]?.type === "skip" ? skipId : null;
  lastViewedSkipId = candidate;
  return chrome.storage.local.set({ [LAST_SKIP_KEY]: candidate });
}

function clearRememberedSkip() {
  lastViewedSkipId = null;
  return chrome.storage.local.set({ [LAST_SKIP_KEY]: null });
}

// Restores the last working skip from storage when the user returns to the
// Skips tab after visiting Home or Closing.
async function restoreRememberedSkip() {
  const stored = await chrome.storage.local.get([SKIPS_KEY, LAST_SKIP_KEY]);
  const storedSkips = stored[SKIPS_KEY] ?? {};
  const rememberedId = stored[LAST_SKIP_KEY] ?? null;
  const rememberedSkip = rememberedId ? storedSkips[rememberedId] : null;

  if (!rememberedSkip || rememberedSkip.type !== "skip") {
    lastViewedSkipId = null;
    return null;
  }

  skips = storedSkips;
  lastViewedSkipId = rememberedId;
  activeSkipId = rememberedId;
  currentView = "skip";

  await chrome.storage.local.set({
    [ACTIVE_KEY]: rememberedId,
    [CURRENT_VIEW_KEY]: "skip"
  });
  return rememberedSkip;
}

// Get Ordered Stored Skips
// *******************
// Returns saved text-note skips in newest-first order.
function getOrderedStoredSkips() {
  return Object.values(skips)
    .filter((skip) => skip.type === "skip")
    .sort((a, b) => (b.createdAt ?? 0) - (a.createdAt ?? 0));
}

// Get First Closing Note
// *******************
// Returns the first saved closing note if one exists.
function getFirstClosingNote() {
  return Object.values(skips).find((skip) => skip.type === "closing") || null;
}

// Set Topbar Actions Visibility
// *******************
// Shows or hides global actions based on the active view.
function setTopbarActionsVisibility() {
  return;
}

function updateTopTabActiveState() {
  const isHome = currentView === "home";
  const isSkips = currentView === "all-skips" || currentView === "skip" || currentView === "empty";
  const isClosing = currentView === "closing";

  homeBtn.classList.toggle("tabAddBtnActive", isHome);
  skipsBtn.classList.toggle("tabAddBtnActive", isSkips);
  closingTabBtn.classList.toggle("tabAddBtnActive", isClosing);
}

// Load Main View
// *******************
// Loads the requested HTML view into the editor shell.
async function loadMainView(fileName) {
  const response = await fetch(chrome.runtime.getURL(`html/${fileName}`));
  const html = await response.text();
  mainContentEl.innerHTML = html;

  currentEditorEl = document.getElementById("editor");

  if (fileName === "home.html") {
    bindHomeView();
  } else if (fileName === "all-skips.html") {
    bindAllSkipsView();
  } else if (fileName === "empty-note.html") {
    bindEmptyNoteView();
  } else if (fileName === "closing.html") {
    bindClosingView();
  }
}

// Bind Home View
// *******************
// Prepares and loads the home dashboard.
function bindHomeView() {
  const statusEl = document.getElementById("homeDashboardStatus");
  const pbxAgentSelect = document.getElementById("homePbxAgentSelect");

  if (!statusEl || !pbxAgentSelect) return;

  const refs = {
    statusEl,
    pbxAgentSelect,
    notesEl: document.getElementById("homeDashboardNotes"),
    outgoingTotalEl: document.getElementById("outgoingTotalValue"),
    outgoingDurationEl: document.getElementById("outgoingDurationValue"),
    incomingTotalEl: document.getElementById("incomingTotalValue"),
    incomingDurationEl: document.getElementById("incomingDurationValue"),
    combinedTotalEl: document.getElementById("combinedTotalValue"),
    combinedDurationEl: document.getElementById("combinedDurationValue")
  };

  pbxAgentSelect.addEventListener("change", async () => {
    homeSelectedPbxAgent = pbxAgentSelect.value || "";
    await chrome.storage.local.set({ [HOME_PBX_AGENT_KEY]: homeSelectedPbxAgent });
    renderHomeDashboard(refs);
  });

  void initializeHomeView(refs);
}

async function initializeHomeView(refs) {
  const stored = await chrome.storage.local.get([HOME_PBX_AGENT_KEY]);
  homeSelectedPbxAgent = stored[HOME_PBX_AGENT_KEY] || "";
  await loadHomeDashboardData(refs, false);
}

function setHomeDashboardStatus(refs, text) {
  if (refs?.statusEl) refs.statusEl.textContent = text;
}

function setHomeDashboardLoading(refs, isLoading, text) {
  if (!refs?.statusEl) return;
  refs.statusEl.classList.toggle("homeDashboardStatusLoading", !!isLoading);
  if (text) refs.statusEl.textContent = text;
}

function fillHomeMetric(card, values) {
  if (!card) return;
  card.totalEl.textContent = values.total || "--";
  card.durationEl.textContent = values.duration || "--";
}

function getDashboardRecord(sourceData, key, selectedAgent) {
  const records = Array.isArray(sourceData?.records) ? sourceData.records : [];
  const summaryRecord = sourceData?.summaryRecord || null;

  if (!selectedAgent || normalizeAgentName(selectedAgent) === normalizeAgentName("All Users")) {
    return summaryRecord || records[0] || null;
  }

  const normalizedSelected = normalizeAgentName(selectedAgent);
  return records.find((record) => normalizeAgentName(record?.[key]) === normalizedSelected) || summaryRecord || null;
}

function renderHomeDashboard(refs) {
  const pbxAgents = Array.isArray(homeDashboardData?.pbxAgents) ? homeDashboardData.pbxAgents : [];
  const availableAgents = [];
  const seenAgents = new Set();
  const addAgent = (agent) => {
    const cleaned = String(agent || "").trim();
    if (!cleaned) return;

    const normalized = normalizeAgentName(cleaned);
    if (!normalized || normalized === normalizeAgentName(HOME_ALL_USERS_LABEL) || seenAgents.has(normalized)) return;

    seenAgents.add(normalized);
    availableAgents.push(cleaned);
  };

  for (const agent of pbxAgents) {
    addAgent(agent);
  }

  const hasSelectableData = availableAgents.length > 0 || !!homeDashboardData?.hasData;
  const selectedPbxAgent = availableAgents.find((agent) => agent === homeSelectedPbxAgent) || "";

  homeSelectedPbxAgent = selectedPbxAgent;
  refs.pbxAgentSelect.innerHTML = "";

  if (!hasSelectableData) {
    const option = document.createElement("option");
    option.value = "";
    option.textContent = "No numbers found";
    refs.pbxAgentSelect.appendChild(option);
    refs.pbxAgentSelect.disabled = true;
  } else {
    refs.pbxAgentSelect.disabled = false;

    const allUsersOption = document.createElement("option");
    allUsersOption.value = "";
    allUsersOption.textContent = HOME_ALL_USERS_LABEL;
    refs.pbxAgentSelect.appendChild(allUsersOption);

    for (const agent of availableAgents) {
      const option = document.createElement("option");
      option.value = agent;
      option.textContent = agent;
      refs.pbxAgentSelect.appendChild(option);
    }

    refs.pbxAgentSelect.value = selectedPbxAgent;
  }

  const outgoingRecord = getDashboardRecord(homeDashboardData?.outgoing, "user", selectedPbxAgent);
  const incomingRecord = getDashboardRecord(homeDashboardData?.incoming, "user", selectedPbxAgent);
  const combinedRecord = getDashboardRecord(homeDashboardData?.combined, "user", selectedPbxAgent);

  fillHomeMetric({
    totalEl: refs.outgoingTotalEl,
    durationEl: refs.outgoingDurationEl
  }, {
    total: outgoingRecord?.total,
    duration: outgoingRecord?.duration
  });

  fillHomeMetric({
    totalEl: refs.incomingTotalEl,
    durationEl: refs.incomingDurationEl
  }, {
    total: incomingRecord?.total,
    duration: incomingRecord?.duration
  });

  fillHomeMetric({
    totalEl: refs.combinedTotalEl,
    durationEl: refs.combinedDurationEl
  }, {
    total: combinedRecord?.total,
    duration: combinedRecord?.duration
  });

  const notes = [];
  for (const source of ["outgoing", "incoming", "combined"]) {
    const message = homeDashboardData?.[source]?.message;
    if (message) notes.push(message);
  }

  refs.notesEl.replaceChildren();

  if (notes.length) {
    for (const noteText of notes) {
      const note = document.createElement("div");
      note.className = "homeDashboardNote";
      note.textContent = noteText;
      refs.notesEl.appendChild(note);
    }
  }

  const updatedAt = homeDashboardData?.fetchedAt ? new Date(homeDashboardData.fetchedAt).toLocaleTimeString() : "";
  if (updatedAt && homeDashboardData?.hasData) {
    setHomeDashboardStatus(refs, `Updated ${updatedAt}${selectedPbxAgent ? ` | PBX ${selectedPbxAgent}` : ""}`);
  } else {
    setHomeDashboardStatus(refs, "No PBX data available.");
  }
}

function requestHomeDashboardData(forceRefresh) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({
      type: "FETCH_HOME_DASHBOARD",
      forceRefresh
    }, (response) => {
      const runtimeError = chrome.runtime.lastError;
      if (runtimeError) {
        reject(new Error(runtimeError.message));
        return;
      }

      resolve(response || null);
    });
  });
}

async function loadHomeDashboardData(refs, forceRefresh) {
  setHomeDashboardLoading(
    refs,
    true,
    forceRefresh ? "Reloading PBX data..." : "Loading PBX data..."
  );

  try {
    const response = await requestHomeDashboardData(forceRefresh);
    homeDashboardData = response || { pbxAgents: [], hasData: false };

    if (!homeDashboardData?.ok && !homeDashboardData?.hasData) {
      setHomeDashboardLoading(refs, false, "Unable to load dashboard data.");
    }

    renderHomeDashboard(refs);

    await chrome.storage.local.set({
      [HOME_PBX_AGENT_KEY]: homeSelectedPbxAgent
    });
  } catch (error) {
    homeDashboardData = {
      ok: false,
      pbxAgents: [],
      hasData: false,
      outgoing: { records: [], message: error?.message || "Dashboard request failed." },
      incoming: { records: [], message: "" },
      combined: { records: [], message: "" }
    };
    renderHomeDashboard(refs);
    setHomeDashboardLoading(refs, false, "Unable to load dashboard data.");
  }
}

async function refreshHomeDashboardInBackground() {
  if (homeRefreshInFlight) return;
  if (currentView !== "home") return;

  homeRefreshInFlight = true;

  try {
    const statusEl = document.getElementById("homeDashboardStatus");
    if (statusEl) {
      statusEl.classList.add("homeDashboardStatusLoading");
      statusEl.textContent = "Reloading PBX data...";
    }

    const response = await requestHomeDashboardData(true);
    homeDashboardData = response || homeDashboardData;

    if (currentView === "home") {
      await renderActiveView();
    }
  } catch (_error) {
    const statusEl = document.getElementById("homeDashboardStatus");
    if (statusEl) {
      statusEl.classList.remove("homeDashboardStatusLoading");
      statusEl.textContent = "Unable to reload PBX data.";
    }
  } finally {
    homeRefreshInFlight = false;
  }
}

// Bind All Skips View
// *******************
// Renders the saved skips list and its item actions.
function bindAllSkipsView() {
  const addNoteBtn = document.getElementById("addNoteBtn");
  const listEl = document.getElementById("allSkipsList");
  const filterBtn = document.getElementById("skipFilterBtn");
  const filterMenu = document.getElementById("skipFilterMenu");
  const renderFilterLabel = () => {
    if (allSkipsFilter === "🗃️ NEW") return "🗃️";
    if (allSkipsFilter === "📞 CALLED IN") return "📞";
    if (allSkipsFilter === "🔥 IMPORTANT") return "🔥";
    return "Filter";
  };
  if (addNoteBtn) {
    addNoteBtn.addEventListener("click", async () => {
      await saveActiveSkipText();
      await createNoteTab("empty");
    });
  }

  if (filterBtn && filterMenu) {
    filterBtn.textContent = renderFilterLabel();

    filterBtn.addEventListener("click", () => {
      filterMenu.classList.toggle("allSkipsFilterMenuOpen");
    });

    for (const option of filterMenu.querySelectorAll(".allSkipsFilterOption")) {
      option.addEventListener("click", () => {
        allSkipsFilter = option.getAttribute("data-filter") || "";
        filterBtn.textContent = renderFilterLabel();
        filterMenu.classList.remove("allSkipsFilterMenuOpen");
        loadMainView("all-skips.html");
      });
    }

    document.addEventListener("click", (event) => {
      if (!filterMenu.contains(event.target) && !filterBtn.contains(event.target)) {
        filterMenu.classList.remove("allSkipsFilterMenuOpen");
      }
    }, { once: true });
  }

  if (!listEl) return;

  const ordered = getOrderedStoredSkips().filter((skip) => {
    if (!allSkipsFilter) return true;
    return normalizeSkipClassification(skip.classification) === allSkipsFilter;
  });

  if (!ordered.length) {
    listEl.innerHTML = `<div class="allSkipsEmpty">${allSkipsFilter ? "No skips match the selected filter." : "No saved skips yet."}</div>`;
    return;
  }

  const fragment = document.createDocumentFragment();

  for (const skip of ordered) {
    const summary = buildSkipListSummary(skip);

    const item = document.createElement("section");
    item.className = "allSkipsItem";

    const top = document.createElement("div");
    top.className = "allSkipsItemTop";

    const summaryWrap = document.createElement("div");
    summaryWrap.className = "allSkipsSummary";

    const classification = document.createElement("div");
    classification.className = "allSkipsClassification";
    classification.textContent = `[${summary.classification}]`;

    const primaryLine = document.createElement("div");
    primaryLine.className = "allSkipsPrimaryLine";
    primaryLine.textContent = summary.primaryLine;

    const detailOne = document.createElement("div");
    detailOne.className = "allSkipsDetailLine";
    detailOne.textContent = summary.identityLine;

    const detailTwo = document.createElement("div");
    detailTwo.className = "allSkipsDetailLine";
    detailTwo.textContent = summary.addressLine;

    const detailThree = document.createElement("div");
    detailThree.className = "allSkipsDetailLine";
    detailThree.textContent = summary.phoneLine;

    summaryWrap.appendChild(classification);
    summaryWrap.appendChild(primaryLine);
    summaryWrap.appendChild(detailOne);
    summaryWrap.appendChild(detailTwo);
    summaryWrap.appendChild(detailThree);

    const actions = document.createElement("div");
    actions.className = "allSkipsActions";

    const openBtn = document.createElement("button");
    openBtn.type = "button";
    openBtn.className = "btn exportSkipBtn";
    openBtn.textContent = "Open";
    openBtn.addEventListener("click", async () => {
      await switchToSkip(skip.id);
    });

    const deleteBtn = document.createElement("button");
    deleteBtn.type = "button";
    deleteBtn.className = "skipDeleteBtn noteIconBtn allSkipsDeleteBtn";
    deleteBtn.setAttribute("aria-label", "Delete");
    deleteBtn.setAttribute("data-tooltip", "Delete");
    deleteBtn.innerHTML = `<img src="../imgs/delete.png" alt="Delete" class="noteBtnIcon" />`;
    deleteBtn.addEventListener("click", async () => {
      await deleteSkip(skip.id);
    });

    actions.appendChild(openBtn);
    actions.appendChild(deleteBtn);

    top.appendChild(summaryWrap);
    top.appendChild(actions);
    item.appendChild(top);
    fragment.appendChild(item);
  }

  listEl.replaceChildren(fragment);
}

// Bind Empty Note View
// *******************
// Connects the note controls and text editor for skip-style notes.
function bindEmptyNoteView() {
  if (!currentEditorEl) return;

  const activeTab = getActiveTab();
  const backBtn = document.getElementById("backToSkipsBtn");
  const undoBtn = document.getElementById("undoNoteBtn");
  const copyBtn = document.getElementById("copyNoteBtn");
  const typeSelect = document.getElementById("skipTypeSelect");
  const closeBtn = document.getElementById("closeSkipBtn");
  const deleteBtn = document.getElementById("deleteSkipBtn");

  currentEditorEl.value = activeTab?.text ?? "";
  currentEditorEl.addEventListener("input", () => {
    scheduleSave();
  });

  if (backBtn) {
    backBtn.addEventListener("click", async () => {
      await saveActiveSkipText();
      activeSkipId = null;
      currentView = "all-skips";
      await clearRememberedSkip();
      await chrome.storage.local.set({
        [ACTIVE_KEY]: null,
        [CURRENT_VIEW_KEY]: "all-skips"
      });
      await renderActiveView();
    });
  }

  if (undoBtn) {
    undoBtn.addEventListener("click", () => {
      undoEditorChange();
    });
  }

  if (copyBtn) {
    copyBtn.addEventListener("click", async () => {
      await copyText(currentEditorEl.value);
    });
  }

  if (typeSelect) {
    const isSkip = activeTab?.type === "skip";
    typeSelect.value = normalizeSkipClassification(activeTab?.classification);
    typeSelect.disabled = !isSkip;
    typeSelect.style.display = isSkip ? "" : "none";

    typeSelect.addEventListener("change", async () => {
      await updateSkipClassification(typeSelect.value);
    });
  }

  if (closeBtn) {
    const isTextNote = activeTab?.type === "skip";
    closeBtn.style.display = isTextNote ? "" : "none";
    closeBtn.addEventListener("click", async () => {
      await closeCurrentTextNote();
    });
  }

  if (deleteBtn) {
    const isTextNote = activeTab?.type === "skip";
    deleteBtn.style.display = isTextNote ? "" : "none";
    deleteBtn.addEventListener("click", async () => {
      if (!activeSkipId) return;
      await deleteSkip(activeSkipId);
    });
  }
}

// Bind Closing View
// *******************
// Wires the closing amount form and calculated outputs.
function bindClosingView() {
  const amountEl = document.getElementById("closingAmount");
  const notesEl = document.getElementById("closingNotes");
  const calcDisplayEl = document.getElementById("closingCalcDisplay");
  const calcButtons = Array.from(document.querySelectorAll("[data-calc-action], [data-calc-value]"));
  const copyBtn = document.getElementById("closingCopyBtn");
  const clearBtn = document.getElementById("closingClearBtn");
  if (!amountEl || !notesEl || !calcDisplayEl) return;

  const activeTab = getActiveTab();
  const closingData = {
    amount: activeTab?.data?.amount ?? "",
    notes: activeTab?.data?.notes ?? "",
    calcDisplay: activeTab?.data?.calcDisplay ?? "0",
    calcExpression: activeTab?.data?.calcExpression ?? "0"
  };

  let calcExpression = String(closingData.calcExpression || "0");

  const parseDecimalValue = (value = "") => Number(String(value || "").replace(/[$,]/g, "")) || 0;

  const formatDecimalString = (value = "") => {
    const cleaned = String(value || "").replace(/[^\d.]/g, "");
    if (!cleaned) return "";

    const parts = cleaned.split(".");
    const integerPart = (parts[0] || "0").replace(/^0+(?=\d)/, "");
    const normalizedInteger = integerPart ? integerPart.replace(/\B(?=(\d{3})+(?!\d))/g, ",") : "0";
    const decimalPart = parts.slice(1).join("").slice(0, 2);
    const formattedNumber = decimalPart ? `${normalizedInteger}.${decimalPart}` : normalizedInteger;
    return `$${formattedNumber}`;
  };

  const formatPlainNumberString = (value = "") => {
    const cleaned = String(value || "").replace(/[^\d.]/g, "");
    if (!cleaned) return "";

    const parts = cleaned.split(".");
    const integerPart = (parts[0] || "0").replace(/^0+(?=\d)/, "");
    const normalizedInteger = integerPart ? integerPart.replace(/\B(?=(\d{3})+(?!\d))/g, ",") : "0";
    const decimalPart = parts.slice(1).join("").slice(0, 2);
    return decimalPart ? `${normalizedInteger}.${decimalPart}` : normalizedInteger;
  };

  const formatExpressionWithCommas = (expression = "") => {
    const sanitized = String(expression || "0").replace(/[^\d+\-*/.]/g, "");
    const segments = sanitized.split(/([+\-*/])/);
    return segments
      .map((segment) => (/^[+\-*/]$/.test(segment) ? segment : formatPlainNumberString(segment)))
      .join(" ")
      .replace(/\s+/g, " ")
      .trim() || "0";
  };

  amountEl.value = formatDecimalString(closingData.amount);
  notesEl.value = closingData.notes;
  calcDisplayEl.value = formatExpressionWithCommas(calcExpression);

  if (closingKeyboardHandler) {
    document.removeEventListener("keydown", closingKeyboardHandler);
    closingKeyboardHandler = null;
  }

  const persistClosingData = (patch) => {
    if (!activeSkipId || !skips[activeSkipId]) return;

    skips[activeSkipId].data = {
      amount: amountEl.value,
      notes: notesEl.value,
      calcDisplay: calcDisplayEl.value,
      calcExpression,
      ...skips[activeSkipId].data,
      ...patch
    };

    chrome.storage.local.set({ [SKIPS_KEY]: skips });
  };

  const update = () => {
    const amount = parseDecimalValue(amountEl.value);

    document.getElementById("closing70").textContent = formatMoney(amount * 0.70);
    document.getElementById("closing80").textContent = formatMoney(amount * 0.80);
    document.getElementById("closing80Half").textContent = formatMoney((amount * 0.80) / 2);
    document.getElementById("closing20").textContent = formatMoney(amount * 0.20);
    document.getElementById("closing80Eighth").textContent = formatMoney((amount * 0.80) / 8);

    persistClosingData({ amount: amountEl.value });
  };

  amountEl.addEventListener("input", () => {
    const cursorOffset = amountEl.value.length - amountEl.selectionStart;
    amountEl.value = formatDecimalString(amountEl.value);
    const nextPosition = Math.max(0, amountEl.value.length - cursorOffset);
    amountEl.setSelectionRange(nextPosition, nextPosition);
    update();
  });
  notesEl.addEventListener("input", () => {
    persistClosingData({ notes: notesEl.value });
  });

  const setCalculatorExpression = (nextExpression) => {
    calcExpression = String(nextExpression || "0").replace(/[^\d+\-*/.]/g, "") || "0";
    calcDisplayEl.value = formatExpressionWithCommas(calcExpression);
    persistClosingData({
      calcDisplay: calcDisplayEl.value,
      calcExpression
    });
  };

  const normalizeCalculatorDisplay = (rawValue = "") => {
    const cleaned = String(rawValue || "").replace(/[^\d+\-*/.]/g, "");
    return cleaned || "0";
  };

  const appendCalculatorValue = (currentExpression, value) => {
    const current = normalizeCalculatorDisplay(currentExpression);

    if (/^\d$/.test(value)) {
      return current === "0" ? value : `${current}${value}`;
    }

    if (value === ".") {
      const lastSegment = current.split(/[+\-*/]/).pop() || "";
      if (lastSegment.includes(".")) return current;
      if (/[+\-*/]$/.test(current)) return `${current}0.`;
      return `${current}.`;
    }

    if (!/[+\-*/]/.test(value)) return current;
    if (current === "0" && value !== "-") return current;
    if (/[+\-*/]$/.test(current)) return `${current.slice(0, -1)}${value}`;
    return `${current}${value}`;
  };

  const computeCalculatorExpression = (expression) => {
    const sanitized = normalizeCalculatorDisplay(expression).replace(/([+\-*/])$/g, "");
    if (!sanitized || sanitized === "-") return 0;

    const tokens = [];
    let currentNumber = "";
    let expectNumber = true;

    for (const char of sanitized) {
      if (/\d|\./.test(char)) {
        currentNumber += char;
        expectNumber = false;
        continue;
      }

      if (char === "-" && expectNumber) {
        currentNumber = currentNumber ? `${currentNumber}-` : "-";
        continue;
      }

      if (currentNumber) {
        tokens.push(Number(currentNumber));
        currentNumber = "";
      }

      tokens.push(char);
      expectNumber = true;
    }

    if (currentNumber) {
      tokens.push(Number(currentNumber));
    }

    if (!tokens.length) return 0;

    const collapsed = [tokens[0]];
    for (let i = 1; i < tokens.length; i += 2) {
      const operator = tokens[i];
      const operand = tokens[i + 1];
      if ((operator === "*" || operator === "/") && typeof operand === "number") {
        const left = Number(collapsed.pop() || 0);
        collapsed.push(operator === "*" ? left * operand : left / operand);
      } else {
        collapsed.push(operator, operand);
      }
    }

    let result = Number(collapsed[0] || 0);
    for (let i = 1; i < collapsed.length; i += 2) {
      const operator = collapsed[i];
      const operand = Number(collapsed[i + 1] || 0);
      result = operator === "+" ? result + operand : result - operand;
    }

    return Number.isFinite(result) ? Number(result.toFixed(10)) : 0;
  };

  const evaluateCalculator = () => {
    const result = computeCalculatorExpression(calcExpression);
    setCalculatorExpression(String(result));
  };

  const flashCalculatorButton = (button) => {
    if (!button) return;
    button.classList.add("closingCalcBtnPressed");
    window.setTimeout(() => {
      button.classList.remove("closingCalcBtnPressed");
    }, 120);
  };

  const findCalculatorButton = ({ action = "", value = "" } = {}) =>
    calcButtons.find((button) =>
      (action && button.getAttribute("data-calc-action") === action) ||
      (value && button.getAttribute("data-calc-value") === value)
    ) || null;

  for (const button of calcButtons) {
    button.addEventListener("click", () => {
      const action = button.getAttribute("data-calc-action");
      const value = button.getAttribute("data-calc-value");
      flashCalculatorButton(button);

      if (action === "clear") {
        setCalculatorExpression("0");
        return;
      }

      if (action === "backspace") {
        const nextValue = calcExpression.length > 1 ? calcExpression.slice(0, -1) : "0";
        setCalculatorExpression(nextValue);
        return;
      }

      if (action === "equals") {
        evaluateCalculator();
        return;
      }

      if (!value) return;
      setCalculatorExpression(appendCalculatorValue(calcExpression, value));
    });
  }

  calcDisplayEl.addEventListener("beforeinput", (event) => {
    event.preventDefault();
  });

  calcDisplayEl.addEventListener("paste", (event) => {
    event.preventDefault();
  });

  calcDisplayEl.addEventListener("input", () => {
    setCalculatorExpression(normalizeCalculatorDisplay(calcDisplayEl.value));
  });

  closingKeyboardHandler = (event) => {
    if (currentView !== "closing") return;

    const target = event.target;
    if (target === notesEl || target === amountEl) return;

    let action = "";
    let value = "";

    if (/^\d$/.test(event.key)) {
      value = event.key;
    } else if (["+", "-", "*", "/", "."].includes(event.key)) {
      value = event.key;
    } else if (event.key === "Enter" || event.key === "=") {
      action = "equals";
    } else if (event.key === "Backspace") {
      action = "backspace";
    } else if (event.key === "Escape" || event.key.toLowerCase() === "c") {
      action = "clear";
    } else {
      return;
    }

    event.preventDefault();

    const matchingButton = findCalculatorButton({ action, value });
    flashCalculatorButton(matchingButton);

    if (action === "clear") {
      setCalculatorExpression("0");
      return;
    }

    if (action === "backspace") {
      const nextValue = calcExpression.length > 1 ? calcExpression.slice(0, -1) : "0";
      setCalculatorExpression(nextValue);
      return;
    }

    if (action === "equals") {
      evaluateCalculator();
      return;
    }

    setCalculatorExpression(appendCalculatorValue(calcExpression, value));
  };

  document.addEventListener("keydown", closingKeyboardHandler);

  if (copyBtn) {
    copyBtn.addEventListener("click", async () => {
      if (currentView !== "closing") return;
      await copyText(notesEl.value || "");
    });
  }

  if (clearBtn) {
    clearBtn.addEventListener("click", () => {
      amountEl.value = "";
      notesEl.value = "";
      setCalculatorExpression("0");
      update();
      persistClosingData({
        amount: "",
        notes: "",
        calcDisplay: "0",
        calcExpression: "0"
      });
    });
  }

  update();
}

// Format Money
// *******************
// Converts a numeric value to a fixed two-decimal string.
function formatMoney(value) {
  return `$${Number(value || 0).toFixed(2)}`;
}

// Build Closing Export Text
// *******************
// Builds the copied text for a closing note.
function buildClosingExportText(activeTab) {
  const amount = activeTab?.data?.amount || "";
  const notes = String(activeTab?.data?.notes || "").trim();
  const value = Number(amount || 0);
  const notesBlock = notes ? `\n\nNOTES\n${notes}` : "";

  return (
`CLOSING AMOUNT
${amount}

70%
${formatMoney(value * 0.70)}

80%
${formatMoney(value * 0.80)}

80% / 2
${formatMoney((value * 0.80) / 2)}

20%
${formatMoney(value * 0.20)}

80% / 8
${formatMoney((value * 0.80) / 8)}${notesBlock}`
  );
}

// Copy Text
// *******************
// Copies plain text to the clipboard.
async function copyText(text) {
  await navigator.clipboard.writeText(text || "");
}

// Undo Editor Change
// *******************
// Runs an undo action in the current editor and schedules a save.
function undoEditorChange() {
  if (!currentEditorEl) return;

  currentEditorEl.focus();
  document.execCommand("undo");
  scheduleSave();
}

// Update Skip Classification
// *******************
// Saves the selected classification on the active skip.
async function updateSkipClassification(nextClassification) {
  const activeTab = getActiveTab();
  if (!activeTab || activeTab.type !== "skip") return;

  skips[activeSkipId].classification = normalizeSkipClassification(nextClassification);
  await chrome.storage.local.set({ [SKIPS_KEY]: skips });
}

// Get Skip Sections
// *******************
// Parses a skip template into named sections keyed by heading.
function getSkipSections(text) {
  const sections = {};
  let currentSection = "";

  for (const sectionName of SKIP_SECTION_NAMES) {
    sections[sectionName] = [];
  }

  for (const line of String(text || "").split(/\r?\n/)) {
    const trimmed = line.trim();

    if (SKIP_SECTION_NAMES.includes(trimmed)) {
      currentSection = trimmed;
      continue;
    }

    if (!currentSection || !trimmed) continue;
    sections[currentSection].push(trimmed);
  }

  return sections;
}

// Get First Section Line
// *******************
// Returns the first populated line from a parsed skip section.
function getFirstSectionLine(sections, sectionName) {
  return sections?.[sectionName]?.find(Boolean) || "";
}

// Build Identity Line
// *******************
// Combines SSN, DOB, and age into the summary display format.
function buildIdentityLine(ssn, dob, age) {
  const left = ssn || "-";
  const rightBase = dob || "-";
  const right = age ? `${rightBase} (${age})` : rightBase;
  return `${left} | ${right}`;
}

// Build Primary Summary Line
// *******************
// Combines claim and name into the main All Skips summary line.
function buildPrimarySummaryLine(claim, name) {
  const cleanClaim = claim || "";
  const cleanName = name || "";
  const separator = " \u2014 ";

  if (cleanClaim && cleanName) return `${cleanName}${separator}${cleanClaim}`;
  if (cleanName) return cleanName;
  if (cleanClaim) return cleanClaim;
  return "Untitled Skip";
}

// Build Skip List Summary
// *******************
// Creates the formatted All Skips summary fields from a saved skip.
function buildSkipListSummary(skip) {
  const sections = getSkipSections(skip?.text || "");
  const name = getFirstSectionLine(sections, "NAME") || skip?.title || "Empty Note";
  const claim = getFirstSectionLine(sections, "CLAIM");
  const ssn = getFirstSectionLine(sections, "SSN");
  const dob = getFirstSectionLine(sections, "DOB");
  const age = getFirstSectionLine(sections, "AGE");
  const addressLine = getFirstSectionLine(sections, "ADDRESS") || "-";
  const phoneLine = getFirstSectionLine(sections, "PRIME/CELL") || "-";

  return {
    classification: normalizeSkipClassification(skip?.classification),
    primaryLine: buildPrimarySummaryLine(claim, name),
    identityLine: buildIdentityLine(ssn, dob, age),
    addressLine,
    phoneLine
  };
}

// Render Active View
// *******************
// Chooses which main view to display based on current state.
async function renderActiveView() {
  const activeTab = getActiveTab();
  setTopbarActionsVisibility();
  updateTopTabActiveState();

  if (currentView === "all-skips") {
    await loadMainView("all-skips.html");
    return;
  }

  if (currentView === "home" || !activeTab) {
    await loadMainView("home.html");
    return;
  }

  if (currentView === "closing") {
    await loadMainView("closing.html");
    return;
  }

  if (currentView === "skip" || currentView === "empty") {
    await loadMainView("empty-note.html");
    return;
  }

  await loadMainView("home.html");
}

// Load Skips
// *******************
// Loads saved items from storage and normalizes their state.
async function loadSkips() {
  const result = await chrome.storage.local.get([SKIPS_KEY, ACTIVE_KEY, LAST_SKIP_KEY, CURRENT_VIEW_KEY]);

  skips = result[SKIPS_KEY] ?? {};
  activeSkipId = result[ACTIVE_KEY] ?? null;
  lastViewedSkipId = result[LAST_SKIP_KEY] ?? null;
  currentView = normalizeStoredView(result[CURRENT_VIEW_KEY]);

  let changed = false;
  for (const skip of Object.values(skips)) {
    if (typeof skip.isOpen !== "boolean") {
      skip.isOpen = true;
      changed = true;
    }

    if (skip.type === "empty") {
      skip.type = "skip";
      skip.title = skip.title || "Empty Note";
      changed = true;
    }

    if (skip.type === "skip") {
      const nextClassification = normalizeSkipClassification(skip.classification);
      if (skip.classification !== nextClassification) {
        skip.classification = nextClassification;
        changed = true;
      }
    }

    if (skip.type === "closing") {
      const nextData = {
        amount: skip.data?.amount ?? "",
        notes: skip.data?.notes ?? "",
        calcDisplay: skip.data?.calcDisplay ?? "0",
        calcExpression: skip.data?.calcExpression ?? "0"
      };

      if (JSON.stringify(skip.data || {}) !== JSON.stringify(nextData)) {
        skip.data = nextData;
        changed = true;
      }
    }
  }

  if (activeSkipId && !skips[activeSkipId]) {
    activeSkipId = null;
    changed = true;
  }

  if (lastViewedSkipId && skips[lastViewedSkipId]?.type !== "skip") {
    lastViewedSkipId = null;
    changed = true;
  }

  // If the popup reloads while the user is conceptually on the Skips tab,
  // restore the last working skip before rendering.
  if (!activeSkipId && currentView === "skip" && lastViewedSkipId && skips[lastViewedSkipId]?.type === "skip") {
    activeSkipId = lastViewedSkipId;
    changed = true;
  }

  if (currentView === "skip" && !activeSkipId) {
    currentView = "all-skips";
    changed = true;
  }

  if (changed) {
    await chrome.storage.local.set({
      [SKIPS_KEY]: skips,
      [ACTIVE_KEY]: activeSkipId,
      [LAST_SKIP_KEY]: lastViewedSkipId,
      [CURRENT_VIEW_KEY]: currentView
    });
  }

  await renderActiveView();
}

// Create Note Tab
// *******************
// Creates a new saved item, opens it, and persists it.
async function createNoteTab(type, options = {}) {
  if (type === "empty") {
    type = "skip";
    options = {
      title: "Empty Note",
      text: "",
      classification: DEFAULT_SKIP_CLASSIFICATION,
      ...options
    };
  }

  const id = makeSkipId();

  let title = "New Note";
  let text = "";
  let data = {};
  let classification = "";

  if (type === "skip") {
    title = options.title || "New Skip";
    text = options.text || "";
    classification = normalizeSkipClassification(options.classification);
  } else if (type === "closing") {
    title = "Closing Note";
    data = { amount: "", notes: "", calcDisplay: "0", calcExpression: "0" };
  }

  skips[id] = {
    id,
    type,
    title,
    text,
    data,
    classification,
    isOpen: true,
    createdAt: Date.now()
  };

  activeSkipId = id;
  currentView = type === "skip" ? "skip" : type;

  const nextStorage = {
    [SKIPS_KEY]: skips,
    [ACTIVE_KEY]: activeSkipId,
    [CURRENT_VIEW_KEY]: currentView
  };

  if (type === "skip") {
    lastViewedSkipId = id;
    nextStorage[LAST_SKIP_KEY] = id;
  }

  await chrome.storage.local.set(nextStorage);

  await renderActiveView();
}

// Delete Skip
// *******************
// Permanently removes a saved item from storage.
async function deleteSkip(skipId) {
  if (!skipId || !skips[skipId]) return;

  const wasActive = skipId === activeSkipId;
  delete skips[skipId];

  if (wasActive) {
    activeSkipId = null;
    currentView = "all-skips";
  }

  if (skipId === lastViewedSkipId) {
    lastViewedSkipId = null;
  }

  await chrome.storage.local.set({
    [SKIPS_KEY]: skips,
    [ACTIVE_KEY]: activeSkipId,
    [LAST_SKIP_KEY]: lastViewedSkipId,
    [CURRENT_VIEW_KEY]: currentView
  });

  await renderActiveView();
}

// Rename Skip
// *******************
// Prompts for a new label and saves it to storage.
async function renameSkip(skipId) {
  if (!skipId || !skips[skipId]) return;

  const current = (skips[skipId].title || "").trim();
  const next = prompt("Rename tab:", current);

  if (next === null) return;
  const cleaned = next.trim();
  if (!cleaned) return;

  skips[skipId].title = cleaned;
  await chrome.storage.local.set({ [SKIPS_KEY]: skips });
}

// Switch To Skip
// *******************
// Saves current edits and activates another saved skip.
async function switchToSkip(nextId) {
  if (!nextId) return;
  if (nextId !== activeSkipId) {
    await saveActiveSkipText();
  }

  activeSkipId = nextId;
  currentView = "skip";
  lastViewedSkipId = activeSkipId;
  await chrome.storage.local.set({
    [ACTIVE_KEY]: activeSkipId,
    [LAST_SKIP_KEY]: activeSkipId,
    [CURRENT_VIEW_KEY]: "skip"
  });

  await renderActiveView();
}

// Close Current Text Note
// *******************
// Returns to the All Skips screen without deleting the active text note.
async function closeCurrentTextNote() {
  const activeTab = getActiveTab();
  if (!activeTab) return;
  if (activeTab.type !== "skip") return;

  await saveActiveSkipText();
  activeSkipId = null;
  currentView = "all-skips";
  await clearRememberedSkip();
  await chrome.storage.local.set({
    [ACTIVE_KEY]: null,
    [CURRENT_VIEW_KEY]: "all-skips"
  });
  await renderActiveView();
}

// Open Closing Tab
// *******************
// Opens the saved closing note or creates one if needed.
async function openClosingTab() {
  const activeTab = getActiveTab();
  await saveActiveSkipText();

  if (activeTab?.type === "skip") {
    await rememberSkip(activeTab.id);
  }

  const existingClosing = getFirstClosingNote();
  if (existingClosing) {
    activeSkipId = existingClosing.id;
    currentView = "closing";
    await chrome.storage.local.set({
      [ACTIVE_KEY]: activeSkipId,
      [CURRENT_VIEW_KEY]: "closing"
    });
    await renderActiveView();
    return;
  }

  await createNoteTab("closing");
}

// Save Active Skip Text
// *******************
// Persists the current editor text for the active note.
async function saveActiveSkipText() {
  const activeTab = getActiveTab();
  if (!activeTab) return;
  if (activeTab.type !== "skip") return;
  if (!currentEditorEl) return;

  skips[activeSkipId].text = currentEditorEl.value;
  await chrome.storage.local.set({ [SKIPS_KEY]: skips });
}

function clearClosingNotesDraft() {
  let changed = false;

  for (const skip of Object.values(skips)) {
    if (skip?.type !== "closing") continue;
    if (!skip.data?.notes) continue;
    skip.data = {
      ...skip.data,
      notes: ""
    };
    changed = true;
  }

  if (changed) {
    chrome.storage.local.set({ [SKIPS_KEY]: skips });
  }
}

// Schedule Save
// *******************
// Debounces text saves while the user is typing.
function scheduleSave() {
  if (saveTimer) clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    saveActiveSkipText();
  }, 400);
}

// Clean Number
// *******************
// Removes non-digit characters from search input.
function cleanNumber(val) {
  return (val || "").replace(/\D/g, "");
}

// Search Delvepoint
// *******************
// Opens Delvepoint search and submits the current SSN or phone query.
function searchDelvepoint() {
  const digits = cleanNumber(searchEl.value);

  chrome.tabs.create({
    url: "https://app.delvepoint.com/Luna/searchTypes/PS02"
  }, (tab) => {
    chrome.tabs.onUpdated.addListener(function listener(tabId, info) {
      if (tabId === tab.id && info.status === "complete") {
        chrome.tabs.onUpdated.removeListener(listener);

        chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: (nextDigits) => {
            function setNativeValue(el, value) {
              el.focus();
              el.value = value;
              el.dispatchEvent(new Event("input", { bubbles: true }));
              el.dispatchEvent(new Event("change", { bubbles: true }));
            }

            const isSSN = nextDigits.length === 9;
            const field = document.querySelector(isSSN ? "#ssn" : "#phoneNumber");
            const submit = document.querySelector("#submitBtn");

            if (!field || !submit) return;

            setNativeValue(field, nextDigits);
            submit.click();
          },
          args: [digits]
        });
      }
    });
  });

  searchEl.value = "";
}

window.addEventListener("beforeunload", () => {
  saveActiveSkipText();
  clearClosingNotesDraft();
});

skipsBtn.addEventListener("click", async () => {
  await saveActiveSkipText();
  const activeTab = getActiveTab();

  if (activeTab?.type === "skip") {
    currentView = "skip";
    await rememberSkip(activeTab.id);
    await chrome.storage.local.set({
      [ACTIVE_KEY]: activeTab.id,
      [CURRENT_VIEW_KEY]: "skip"
    });
  } else if (await restoreRememberedSkip()) {
    // restoreRememberedSkip updates the active view state and storage.
  } else {
    activeSkipId = null;
    currentView = "all-skips";
    await chrome.storage.local.set({
      [ACTIVE_KEY]: null,
      [CURRENT_VIEW_KEY]: "all-skips"
    });
  }

  await renderActiveView();
});

homeBtn.addEventListener("click", async () => {
  const activeTab = getActiveTab();
  await saveActiveSkipText();

  if (activeTab?.type === "skip") {
    await rememberSkip(activeTab.id);
  }

  activeSkipId = null;
  currentView = "home";
  await chrome.storage.local.set({
    [ACTIVE_KEY]: null,
    [CURRENT_VIEW_KEY]: "home"
  });
  await renderActiveView();
  void refreshHomeDashboardInBackground();
});

closingTabBtn.addEventListener("click", async () => {
  await openClosingTab();
});

searchEl.addEventListener("keydown", (e) => {
  if (e.key === "Enter") searchDelvepoint();
});

chrome.runtime.onMessage.addListener(() => {
  loadSkips();
});

loadSkips();
