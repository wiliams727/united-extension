const EDITOR_URL = "html/editor.html";
const WINDOW_NAME = "edge-notepad-window";
const HOME_CACHE_TTL_MS = 5 * 60 * 1000;
const HOME_CACHE_KEY = "qs_homeDashboardCache";
const HOME_REFRESH_ALARM = "qs_homeDashboardRefresh";

const PBX_AUTH_HEADER = `Basic ${btoa("maint:xx47j49d7")}`;
const PBX_OUTGOING_URL = "http://pbx20089.8bitllc.com/admin/config.php?type=tool&display=asternic_cdr&tab=outgoing";
const PBX_INCOMING_URL = "http://pbx20089.8bitllc.com/admin/config.php?type=tool&display=asternic_cdr&tab=incoming";
const PBX_COMBINED_URL = "http://pbx20089.8bitllc.com/admin/config.php?type=tool&display=asternic_cdr&tab=combined";

let cachedHomeDashboard = null;

// Open or Focus Editor
// *******************
// Opens the editor popup or focuses the existing one.
async function openOrFocusEditor() {
  const windows = await chrome.windows.getAll({ populate: true });
  const existing = windows.find((windowObj) =>
    windowObj.type === "popup" &&
    windowObj.tabs?.some((tab) => tab.url && tab.url.includes(EDITOR_URL))
  );

  if (existing?.id) {
    await chrome.windows.update(existing.id, { focused: true });
    return;
  }

  await chrome.windows.create({
    url: chrome.runtime.getURL("html/editor.html"),
    type: "popup",
    width: 590,
    height: 760,
    left: 1010,
    top: 0,
    focused: true
  });
}

function decodeHtmlEntities(text = "") {
  return text
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&quot;/gi, '"')
    .replace(/&#39;/gi, "'")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">");
}

function stripHtml(text = "") {
  return decodeHtmlEntities(String(text || "").replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim());
}

function normalizeHeader(text = "") {
  return String(text || "").replace(/\s+/g, " ").trim().toLowerCase();
}

function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function waitForTabComplete(tabId, timeoutMs = 30000) {
  const existing = await chrome.tabs.get(tabId);
  if (existing.status === "complete") {
    await wait(1500);
    return;
  }

  await new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      reject(new Error("Timed out waiting for tab load."));
    }, timeoutMs);

    function listener(updatedTabId, changeInfo) {
      if (updatedTabId !== tabId || changeInfo.status !== "complete") return;
      clearTimeout(timeout);
      chrome.tabs.onUpdated.removeListener(listener);
      resolve();
    }

    chrome.tabs.onUpdated.addListener(listener);
  });

  await wait(1500);
}

async function runInTab(tabId, func, args = []) {
  const results = await chrome.scripting.executeScript({
    target: { tabId },
    func,
    args
  });

  return results?.[0]?.result;
}

function parseSimpleTable(html, requiredHeaders) {
  const tables = html.match(/<table[\s\S]*?<\/table>/gi) || [];

  for (const tableHtml of tables) {
    const headers = Array.from(tableHtml.matchAll(/<th[^>]*>([\s\S]*?)<\/th>/gi)).map((match) => stripHtml(match[1]));
    if (!headers.length) continue;

    const normalizedHeaders = headers.map(normalizeHeader);
    const hasAllHeaders = requiredHeaders.every((header) => normalizedHeaders.includes(normalizeHeader(header)));
    if (!hasAllHeaders) continue;

    const bodyMatch = tableHtml.match(/<tbody[^>]*>([\s\S]*?)<\/tbody>/i);
    const bodyHtml = bodyMatch ? bodyMatch[1] : tableHtml;
    const rowMatches = Array.from(bodyHtml.matchAll(/<tr[^>]*>([\s\S]*?)<\/tr>/gi));
    const records = [];

    for (const rowMatch of rowMatches) {
      const cells = Array.from(rowMatch[1].matchAll(/<td[^>]*>([\s\S]*?)<\/td>/gi)).map((cellMatch) => stripHtml(cellMatch[1]));
      if (!cells.length) continue;

      const record = {};
      headers.forEach((header, index) => {
        record[header] = cells[index] || "";
      });
      records.push(record);
    }

    return records;
  }

  return [];
}

async function fetchPbxReport(url, label) {
  try {
    const response = await fetch(url, {
      headers: {
        Authorization: PBX_AUTH_HEADER
      }
    });

    if (!response.ok) {
      throw new Error(`${response.status} ${response.statusText}`);
    }

    const html = await response.text();
    const rows = parseSimpleTable(html, ["User", "Total", "Duration"]);
    const records = rows
      .map((row) => ({
        user: row.User || "All Users",
        total: row.Total || "--",
        duration: row.Duration || "--"
      }))
      .filter((row) => row.total !== "--" || row.duration !== "--");

    return {
      ok: true,
      records,
      message: records.length ? "" : `${label}: no user rows were available on the report page.`
    };
  } catch (error) {
    return {
      ok: false,
      records: [],
      message: `${label}: ${error.message || "request failed."}`
    };
  }
}

function collectAgents(...groups) {
  const seen = new Set();
  const agents = [];

  for (const group of groups) {
    for (const record of group?.records || []) {
      const candidate = record.user || record.collector || "";
      const cleaned = candidate.replace(/\s+/g, " ").trim();
      if (!cleaned || seen.has(cleaned.toLowerCase())) continue;
      seen.add(cleaned.toLowerCase());
      agents.push(cleaned);
    }
  }

  return agents;
}

function buildHomeDashboardPayload(outgoing, incoming, combined, fetchedAt) {
  const pbxAgents = collectAgents(outgoing, incoming, combined);

  return {
    ok: outgoing.ok || incoming.ok || combined.ok,
    fetchedAt,
    hasData: !!(outgoing.records.length || incoming.records.length || combined.records.length),
    pbxAgents,
    outgoing,
    incoming,
    combined
  };
}

async function refreshHomeDashboardCache() {
  const [outgoing, incoming, combined] = await Promise.all([
    fetchPbxReport(PBX_OUTGOING_URL, "Outgoing calls"),
    fetchPbxReport(PBX_INCOMING_URL, "Incoming calls"),
    fetchPbxReport(PBX_COMBINED_URL, "Combined calls")
  ]);

  cachedHomeDashboard = buildHomeDashboardPayload(outgoing, incoming, combined, Date.now());
  await chrome.storage.local.set({ [HOME_CACHE_KEY]: cachedHomeDashboard });
  return cachedHomeDashboard;
}

async function fetchHomeDashboard(forceRefresh = false) {
  if (!forceRefresh) {
    if (cachedHomeDashboard && cachedHomeDashboard.fetchedAt && Date.now() - cachedHomeDashboard.fetchedAt < HOME_CACHE_TTL_MS) {
      return cachedHomeDashboard;
    }

    const stored = await chrome.storage.local.get([HOME_CACHE_KEY]);
    const savedCache = stored[HOME_CACHE_KEY] || null;
    if (savedCache) {
      cachedHomeDashboard = savedCache;
      return savedCache;
    }

    return {
      ok: true,
      fetchedAt: null,
      hasData: false,
      pbxAgents: [],
      outgoing: { ok: true, records: [], message: "" },
      incoming: { ok: true, records: [], message: "" },
      combined: { ok: true, records: [], message: "" }
    };
  }

  return refreshHomeDashboardCache();
}

async function clearHomeDashboard() {
  cachedHomeDashboard = {
    ok: true,
    fetchedAt: null,
    hasData: false,
    pbxAgents: [],
    outgoing: { ok: true, records: [], message: "" },
    incoming: { ok: true, records: [], message: "" },
    combined: { ok: true, records: [], message: "" }
  };

  await chrome.storage.local.remove([HOME_CACHE_KEY]);
  return cachedHomeDashboard;
}

// Runtime Message Handling
// *******************
// Supports popup lifecycle actions and home dashboard fetches.
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type === "OPEN_EDITOR") {
    openOrFocusEditor();
    return;
  }

  if (msg?.type === "FETCH_HOME_DASHBOARD") {
    fetchHomeDashboard(!!msg.forceRefresh)
      .then((result) => sendResponse(result))
      .catch((error) => {
        sendResponse({
          ok: false,
          fetchedAt: Date.now(),
          pbxAgents: [],
          hasData: false,
          outgoing: { ok: false, records: [], message: error.message || "Dashboard fetch failed." },
          incoming: { ok: false, records: [], message: "" },
          combined: { ok: false, records: [], message: "" }
        });
      });

    return true;
  }

  if (msg?.type === "CLEAR_HOME_DASHBOARD") {
    clearHomeDashboard()
      .then((result) => sendResponse(result))
      .catch((error) => {
        sendResponse({
          ok: false,
          fetchedAt: null,
          hasData: false,
          pbxAgents: [],
          outgoing: { ok: false, records: [], message: error.message || "Unable to clear dashboard cache." },
          incoming: { ok: true, records: [], message: "" },
          combined: { ok: true, records: [], message: "" }
        });
      });

    return true;
  }
});

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create(HOME_REFRESH_ALARM, { periodInMinutes: 5 });
  refreshHomeDashboardCache().catch(() => {});
});

chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create(HOME_REFRESH_ALARM, { periodInMinutes: 5 });
  refreshHomeDashboardCache().catch(() => {});
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm?.name !== HOME_REFRESH_ALARM) return;
  refreshHomeDashboardCache().catch(() => {});
});

// Open editor when clicking the extension icon
chrome.action.onClicked.addListener(async () => {
  openOrFocusEditor();
});
